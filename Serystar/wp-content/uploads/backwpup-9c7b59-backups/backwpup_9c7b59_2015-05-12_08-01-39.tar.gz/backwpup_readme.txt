Usted puede haber notado el archivo manifest.json en este archivo.
manifest.json podría ser necesaria para su posterior restauración de una copia de seguridad de este archivo.
Por favor deje sin tocar manifest.json y en su sitio. De otro modo la seguridad será ignorada.
